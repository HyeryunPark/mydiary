package com.example.mydiary.model;

public class DiaryModel {

    public String diaryDate, diaryPicture, diaryText, userUID, pos;

}
