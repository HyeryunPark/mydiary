package com.example.mydiary.model;

public class UserModel {

    public String userName, userEmail, userUid;
}
