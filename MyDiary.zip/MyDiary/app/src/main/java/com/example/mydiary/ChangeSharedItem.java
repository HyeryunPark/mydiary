package com.example.mydiary;

import com.example.mydiary.Item.Item_myDiary;

public class ChangeSharedItem {

    public int n = 0;
    public Item_myDiary item_myDiary;


}
